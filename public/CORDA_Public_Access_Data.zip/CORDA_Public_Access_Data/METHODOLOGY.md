# CORDA Democratic AI Readiness Index — Methodology

**Version:** 1.0 (Wave 1)
**Maintained by:** CORDA Democracy Fellows — Coleman Snell, Jason Hung, Casimir Wypyski, Eilaf Mohamed
**Last updated:** June 2026
**Step 1 executed:** June 2026 — Data audit and missingness classification complete

---

## Table of Contents

1. [Theoretical Framework](#1-theoretical-framework)
2. [Data Architecture](#2-data-architecture)
3. [Step 1 — Data Audit and Missingness Classification](#step-1--data-audit-and-missingness-classification)
4. [Step 2 — Missingness Threshold and Indicator Eligibility](#step-2--missingness-threshold-and-indicator-eligibility)
5. [Step 3 — Data Imputation](#step-3--data-imputation)
6. [Step 4 — Min-Max Normalisation to 0–100](#step-4--min-max-normalisation-to-0100)
7. [Step 5 — Internal Consistency Checks](#step-5--internal-consistency-checks)
8. [Step 6 — Weighting](#step-6--weighting)
9. [Step 7 — Composite Score Construction](#step-7--composite-score-construction)
10. [Step 8 — Sensitivity and Robustness Analysis](#step-8--sensitivity-and-robustness-analysis)
11. [Analytical Methods for Empirical Outputs](#analytical-methods-for-empirical-outputs)
12. [Deliverable-Specific Methodology](#deliverable-specific-methodology)
13. [Limitations](#limitations)
14. [References](#references)

---

## 1. Theoretical Framework

### 1.1 Research question

Can we construct a valid, replicable composite index that scores democracies on their AI-governance readiness and identifies AI-accelerated democratic backsliding risk?

### 1.2 Five theoretical drivers

The index is organised around five theoretical drivers of democratic backsliding, each operationalised with both AI-specific and non-AI background indicators. The AI-specific indicators capture how AI amplifies the underlying driver; the non-AI indicators establish the baseline democratic health context in which amplification occurs.

| Code | Driver | Theoretical basis | AI amplification vector |
|------|--------|-------------------|-------------------------|
| T1/D1 | Economic Inequality / Relative Deprivation | Meltzer–Richard; Acemoglu & Robinson (2006); Piketty (2014) | Labour displacement, wage polarisation |
| T1/D2 | Information Environment Shocks | Prat & Strömberg (2013); Guriev & Treisman (2022) | Synthetic media, algorithmic curation, micro-targeting |
| T1/D3 | Elite Defection / Intra-Elite Conflict | Goldstone (1991); Turchin (2016); Levitsky & Ziblatt (2018) | Winner-take-all capital accumulation, elite fragmentation |
| T1/D4 | State Capacity Erosion | Besley & Persson (2011); Fukuyama (2011) | AI outpacing regulatory capacity; regulatory arbitrage |
| T1/D5 | Polarization / Affective Tribalism | Iyengar et al. (2019); Abramowitz (2018); V-Dem data | Recommender-system amplification; filter bubbles |

### 1.3 Two index layers

**Layer 1 — AI Readiness Index (cross-sectional, 2023–2025):** Composed exclusively of 29 AI-specific indicators. Designed for the 2025 cross-sectional report and the snapshot layer of the interactive dashboard. Measures current AI exposure and governance preparedness.

**Layer 2 — Democratic Health Panel (longitudinal, 2000–2025):** Composed of 88 non-AI democratic health indicators. Provides the long-run democratic trajectory backdrop against which AI-amplified risk is assessed. Used for the panel regression, latent growth curve modelling, and difference-in-differences analyses in the research paper.

### 1.4 Indicator dimensions

Each indicator is classified along two dimensions:

- **Exposure:** measures the degree to which a country is exposed to AI-driven risks to democracy (e.g., volume of deepfake incidents, commercial AI concentration)
- **Preparedness:** measures the degree to which a country has institutional safeguards, regulatory capacity, or civic resilience in place (e.g., algorithmic transparency laws, AI governance frameworks)

High Exposure + Low Preparedness = highest vulnerability. The composite score for each driver reflects the net balance of exposure and preparedness within that driver.

---

## 2. Data Architecture

### 2.1 Datasets

| File | Rows | Indicators | Countries | Year range |
|------|------|-----------|-----------|------------|
| `ai_indicators.csv` | 4,172 | 29 | 27 | 2000–2026 |
| `non_ai_indicators.csv` | 41,386 | 88 | 27 | 2000–2025 |
| `final_CORDA_dataset.csv` | 45,558 | 117 | 27 | 2000–2026 |

All files follow the same schema: `Year | Country | ISO3 | Driver | Metric | Value | Dataset | Source | Source_File | Source_Type | Source_Year`

The merged file `final_CORDA_dataset.csv` adds an `Indicator Type` column (values: `AI indicator` / `non-AI indicator`).

### 2.2 Country scope

27 countries: Australia, Bangladesh, Brazil, Canada, Chile, China, Denmark, France, Germany, Ghana, India, Indonesia, Israel, Japan, Mexico, Netherlands, New Zealand, Nigeria, Poland, Singapore, South Africa, South Korea, Sweden, Taiwan, United Arab Emirates, United Kingdom, United States.

### 2.3 Key data availability summary

| Indicator group | Temporal coverage | Countries covered |
|----------------|-------------------|------------------|
| V-Dem DSP variables (5 metrics) | 2000–2025 (26 years) | 27 / 27 |
| CAIDP Q9 | 2023–2026 (4 years) | 27 / 27 |
| WB GovTech GTEI | 2020, 2022, 2025 (3 waves) | 27 / 27 |
| Ipsos AI Monitor | 2023–2025 (3 years) | 20 / 27 |
| OECD AI Incidents Monitor | 2016–2023 (8 years) | 18 / 27 |
| GIRAI thematic area scores | 2024 only | 23 / 27 |
| Tortoise sub-pillar scores | 2024 only | 27 / 27 |
| Reuters Institute AI metrics | 2024–2025 (2 years) | 5 / 27 |
| Stanford AI spending | 2025 only | 8 / 27 |
| IMF AIPI, Number of AI Bills, etc. | Single year | varies |
| Non-AI V-Dem indicators | 2000–2025 | 27 / 27 |
| FH FIW, EIU, BTI, IDEA, WJP | Various, 2000–2025 | 15–27 / 27 |

---

## Step 1 — Data Audit and Missingness Classification

**Status: COMPLETED — June 2026**
**Output file:** `step1_missingness_audit.csv` (saved to `/Final Project/`)

**Performed before:** all imputation, normalisation, or weighting steps.

**Purpose:** classify every indicator-country combination as Missing At Random (MAR), Missing Not At Random (MNAR), or observed. This classification determines which imputation method — if any — is applicable.

**Methodological grounding:** The distinction between MAR and MNAR is foundational in the missing data literature (Little & Rubin, 2002) and is explicitly incorporated in the JRC (2005) composite indicator handbook and the Oxford Insights (2026) GIRAI methodology. JRC (2005) states that applying imputation to MNAR data fabricates values and can bias composite scores systematically.

---

### 1.1 Overall missingness results (executed on `final_CORDA_dataset.csv`)

| Classification | Country × Metric combinations | Share |
|---|---|---|
| **Observed** | 2,745 | 86.2% |
| **MNAR_structural_country** | 239 | 7.5% |
| **MNAR_structural_survey** | 202 | 6.3% |
| **MAR_temporal** | 81 cells (WB GovTech only) | — |
| **Total combinations audited** | 3,186 | 100% |

The dataset is 86.2% observed at the country × metric level. All 441 missing combinations fall into MNAR categories (no imputation permissible) except for the 81 WB GovTech temporal cells, which are MAR and eligible for linear interpolation in Step 3.

---

### 1.2 MNAR classifications — no imputation permissible

**MNAR_structural_country (239 combinations):**

| Source | Excluded CORDA countries | Indicators affected | Reason |
|--------|--------------------------|---------------------|--------|
| GIRAI | Bangladesh, Denmark, Israel, Sweden | TA4, TA11, TA14, National AI Policy, Transparency & Explainability | Outside GIRAI's 138-country universe |
| BTI (Bertelsmann) | Australia, Canada, Denmark, France, Germany, Israel, Japan, Netherlands, New Zealand, Sweden, UK, USA | 14 BTI metrics | BTI by design covers only transformation/developing countries |
| IBP Open Budget Survey | All except Bangladesh, Brazil, Chile, China, India, Indonesia | IBP Transparency Score, Budget Oversight Score | IBP samples only select countries per wave |
| WJP Rule of Law | Israel, Taiwan | All 7 WJP factors | These 2 countries not in WJP scoring editions |
| V-Dem election indicators | China | v2elirreg, v2elintim, v2elboycot | China holds no contested multiparty elections |

**MNAR_structural_survey (202 combinations):**

| Source | Missing CORDA countries | Indicators affected |
|--------|------------------------|---------------------|
| Ipsos AI Monitor | UAE, Bangladesh, Denmark, Ghana, Israel, Nigeria, Taiwan | % AI will replace job; % Trust AI not to discriminate |
| Reuters Institute (AI sub-report) | All except Denmark, France, Japan, UK, USA | 6 Reuters AI-and-news metrics |
| OECD Truth Quest (TQ12) | Bangladesh, Chile, China, Denmark, Ghana, India, Indonesia, Israel, New Zealand, Nigeria, Singapore, South Africa, South Korea, Sweden, Taiwan, UAE | TQ12 |
| Stanford AI spending | All except Germany, Denmark, France, UK, Netherlands, Poland, Sweden, USA | Total Public Spending indicator |
| Stanford AI Bills | Ghana, Indonesia, Nigeria, Taiwan | Number of AI Bills |
| OECD AI Incidents Monitor | Bangladesh, Chile, Denmark, Germany, Ghana, Indonesia, Nigeria, Poland, South Africa | AI Incidents count — **presence-only system: absence = zero reported, not confirmed zero incidence** |

---

### 1.3 MAR classification — imputation eligible

**MAR_temporal — WB GovTech only (81 cells):**

The WB GovTech Maturity Index is biennial. Observed waves: 2020, 2022, 2025. Missing years 2021, 2023, 2024 for all 27 countries (27 × 3 = 81 cells). Missingness is entirely due to survey cadence, not country governance characteristics — classified as MAR. Linear interpolation designated in Step 3.

No other MAR cells were identified. All other missingness is structural (MNAR).

---

### 1.4 Single-year AI indicators — temporal imputation impossible

18 of 29 AI indicators have only one year of data. Temporal imputation is mathematically impossible regardless of MAR/MNAR status. These 18 indicators contribute **only to the 2025 cross-sectional report** and cross-sectional dashboard snapshots.

| Indicator | Year | Countries |
|-----------|------|-----------|
| Human Capital and Labor Market Policies (IMF AIPI) | 2023 | 27 |
| TA11: Labour Protection and Right to Work (GIRAI) | 2024 | 23 |
| TA4: Competition Authorities (GIRAI) | 2024 | 23 |
| TA14: Public Participation and Awareness (GIRAI) | 2024 | 23 |
| National AI Policy dimension score (GIRAI) | 2024 | 23 |
| Transparency and Explainability (GIRAI) | 2024 | 23 |
| Commercial Ecosystem: Companies score (Tortoise) | 2024 | 27 |
| Commercial Ecosystem: Funding score (Tortoise) | 2024 | 27 |
| Government Strategy: Strategy score (Tortoise) | 2024 | 27 |
| Government Strategy: Government spend score (Tortoise) | 2024 | 27 |
| Number Of AI-Related Bills Passed Into Law (Stanford) | 2023 | 23 |
| TQ12 Truth Quest: AI-generated disinformation (OECD) | 2024 | 11 |
| % comfortable with news: Entirely by AI (Reuters) | 2025 | 5 |
| % comfortable with news: Mostly by AI (Reuters) | 2025 | 5 |
| % comfortable with news: Mostly by human + AI (Reuters) | 2025 | 5 |
| % comfortable with news: Entirely by human (Reuters) | 2025 | 5 |
| % trust news media to use generative AI (Reuters) | 2024 | 5 |
| Total Public Spending on AI Contracts (Stanford) | 2025 | 8 |

---

### 1.5 Multi-year AI indicators — eligible for longitudinal analysis

| Indicator | Years | Countries | Longitudinal eligibility |
|-----------|-------|-----------|--------------------------|
| v2smgovdom (DSP) | 2000–2025 (T=26) | 27 | Full panel regression, LGM, DiD, scenario projection |
| v2smpardom (DSP) | 2000–2025 (T=26) | 27 | Full panel regression, LGM, DiD, scenario projection |
| v2smpolsoc (DSP) | 2000–2025 (T=26) | 27 | Full panel regression, LGM, DiD, scenario projection |
| v2smmefra (DSP) | 2000–2025 (T=26) | 27 | Full panel regression, LGM, DiD, scenario projection |
| v2smpolhate (DSP) | 2000–2025 (T=26) | 27 | Full panel regression, LGM, DiD, scenario projection |
| OECD AI Incidents Monitor | 2016–2023 (T=8) | 18 | Panel regression; descriptive trend for dashboard |
| CAIDP Q9 Algorithmic Transparency | 2023–2026 (T=4) | 27 | Trend chart only — ordinal, T too small for regression |
| WB GovTech GTEI | 2020/2022/2025 (3 waves) | 27 | Trend chart after interpolation; T=3 waves only |
| Ipsos % AI will replace job | 2023–2025 (T=3) | 20 | Descriptive trend line only; T too small for regression |
| Ipsos % Trust AI not to discriminate | 2024–2025 (T=2) | 20 | Two-point comparison only |
| Reuters % used GenAI for news | 2024–2025 (T=2) | 5 | Two-point comparison only; 5 countries |

---

### 1.6 Non-AI indicator missingness summary

| Dataset | Metrics | Countries covered | Year range | Missingness type |
|---------|---------|------------------|------------|------------------|
| V-Dem (41 variables) | 41 | 27/27 | 2000–2025 | Observed (China election items: MNAR) |
| Freedom House FIW | 10 | 27/27 | 2012–2024 | Observed |
| EIU Democracy Index | 4 | 27/27 | 2006–2024 | Observed |
| IDEA GSoD | 7 | 27/27 | 2000–2024 | Observed |
| CIVICUS Monitor | 2 | 27/27 | 2018–2025 | Observed |
| TI Corruption Perceptions Index | 1 | 27/27 | 2012–2024 | Observed |
| RSF Press Freedom Index | 1 | 27/27 | 2013–2021 | Observed |
| WJP Rule of Law | 7 | 25/27 | 2012–2021 | MNAR: Israel, Taiwan excluded |
| BTI | 14 | 15/27 | 2006–2024 | MNAR: 12 established democracies excluded by design |
| IBP Open Budget Survey | 2 | 6/27 | 2006–2025 | MNAR: only 6 CORDA countries surveyed |

---

### 1.7 Empirical decisions taken at Step 1

1. **No imputation for MNAR cells.** 441 country × metric combinations classified as MNAR will remain missing throughout the pipeline.

2. **81 WB GovTech cells designated MAR_temporal.** Linear interpolation will be applied in Step 3 to fill years 2021, 2023, and 2024.

3. **18 single-year AI indicators are cross-sectional only.** Excluded from all longitudinal analytical methods. Included in the 2025 cross-sectional report and dashboard snapshot layer only.

4. **OECD AI Incidents absence ≠ zero incidence.** The 9 absent CORDA countries receive a missing value, not a score of 0, on this indicator.

5. **BTI and IBP excluded from primary non-AI panel regression.** Used only in supplementary analyses. Core longitudinal models use V-Dem, FH FIW, EIU, IDEA GSoD, CIVICUS, TI CPI, and RSF — these seven sources have full or near-full 27-country coverage.

**Proceed to Step 2.**

---

## Step 2 — Missingness Threshold and Indicator Eligibility

**Status: COMPLETED — June 2026**
**Output file:** `step2_eligibility.csv` (saved to `/Final Project/`)

**Performed after:** Step 1. **Performed before:** imputation and normalisation.

**Purpose:** determine which indicators have sufficient country coverage to be included in the cross-sectional composite, and which should be excluded or assigned reduced weight.

**Methodological grounding:** Oxford Insights GIRAI (2026) applies a 15% missingness threshold: any indicator missing for more than 15% of the country sample is excluded from the composite index. This prevents the composite score from being driven by indicators with very sparse coverage, which would introduce systematic bias favouring countries that happen to be covered.

**Application to CORDA:**

The CORDA sample is 27 countries. 15% of 27 = 4.05, meaning any indicator missing for 5 or more countries fails the threshold under Oxford's strict rule. However, CORDA operates at a smaller N than GIRAI (which covers 193 countries). A strict 15% threshold would exclude many AI-specific indicators that are genuinely informative for the countries where they exist. An adjusted threshold of **≤ 30% missing (≥ 19 / 27 countries)** is used as the strict eligibility cut-off for the composite, with all indicators retained for descriptive reporting regardless of coverage.

### 2.1 Summary results (executed on `final_CORDA_dataset.csv`)

| Layer | Total metrics | Eligible for composite (≥19/27) | Excluded (<19/27) |
|-------|-------------|-------------------------------|------------------|
| AI indicators | 29 | 20 | 9 |
| Non-AI indicators | 89 | 73 | 16 |
| **Total** | **118** | **93** | **25** |

| Longitudinal eligibility (T ≥ 5 years) | AI | Non-AI | Total |
|----------------------------------------|-----|--------|-------|
| Eligible for panel regression | 6 | 84 | 90 |
| Cross-sectional only (T < 5) | 23 | 5 | 28 |

### 2.2 AI indicators — eligibility table

| Indicator | Countries | Years | Composite eligible? | Longitudinal eligible? |
|-----------|-----------|-------|--------------------|-----------------------|
| v2smgovdom | 27 | 26 | ✓ | ✓ |
| v2smmefra | 27 | 26 | ✓ | ✓ |
| v2smpardom | 27 | 26 | ✓ | ✓ |
| v2smpolhate | 27 | 26 | ✓ | ✓ |
| v2smpolsoc | 27 | 26 | ✓ | ✓ |
| CAIDP Q9 Algorithmic Transparency Law | 27 | 4 | ✓ | ✗ (T=4, ordinal) |
| Commercial Ecosystem: Companies score (Tortoise) | 27 | 1 | ✓ | ✗ |
| Commercial Ecosystem: Funding score (Tortoise) | 27 | 1 | ✓ | ✗ |
| Government Strategy: Government spend score (Tortoise) | 27 | 1 | ✓ | ✗ |
| Government Strategy: Strategy score (Tortoise) | 27 | 1 | ✓ | ✗ |
| Human Capital and Labor Market Policies (IMF AIPI) | 27 | 1 | ✓ | ✗ |
| WB GovTech GTEI | 27 | 3 | ✓ | ✗ (T=3 waves) |
| % AI will replace job (Ipsos) | 20 | 3 | ✓ | ✗ (T=3) |
| % I Trust AI not to discriminate (Ipsos/Stanford) | 20 | 2 | ✓ | ✗ (T=2) |
| National AI Policy dimension score (GIRAI) | 23 | 1 | ✓ | ✗ |
| Number of AI-Related Bills Passed Into Law (Stanford) | 23 | 1 | ✓ | ✗ |
| TA11: Labour Protection and Right to Work (GIRAI) | 23 | 1 | ✓ | ✗ |
| TA14: Public Participation and Awareness (GIRAI) | 23 | 1 | ✓ | ✗ |
| TA4: Competition Authorities (GIRAI) | 23 | 1 | ✓ | ✗ |
| Transparency and Explainability (GIRAI) | 23 | 1 | ✓ | ✗ |
| **OECD AI Incidents Monitor** | **18** | **8** | **✗ (33.3% missing)** | **✓ (T=8, panel only)** |
| TQ12 Truth Quest (OECD) | 11 | 1 | ✗ (59.3% missing) | ✗ |
| Total Public Spending on AI Contracts (Stanford) | 8 | 1 | ✗ (70.4% missing) | ✗ |
| % comfortable with news: Entirely by AI (Reuters) | 5 | 1 | ✗ (81.5% missing) | ✗ |
| % comfortable with news: Entirely by human (Reuters) | 5 | 1 | ✗ (81.5% missing) | ✗ |
| % comfortable with news: Mostly AI (Reuters) | 5 | 1 | ✗ (81.5% missing) | ✗ |
| % comfortable with news: Mostly human + AI (Reuters) | 5 | 1 | ✗ (81.5% missing) | ✗ |
| % trust news media to use AI responsibly (Reuters) | 5 | 1 | ✗ (81.5% missing) | ✗ |
| % used GenAI to get news (Reuters) | 5 | 2 | ✗ (81.5% missing) | ✗ |

**Special case — OECD AI Incidents Monitor:** 18/27 countries (33.3% missing) — just below the ≥19 threshold, so excluded from the composite score. However, it has T=8 years of panel data (2016–2023), making it the only AI indicator eligible for panel regression. It is included in all longitudinal analyses as a standalone variable, labelled as a supplementary indicator.

### 2.3 Non-AI indicators — excluded from composite

All 16 excluded non-AI metrics are structural MNAR (classified in Step 1):

| Dataset | Metrics excluded | Countries covered | Reason |
|---------|----------------|------------------|--------|
| BTI (Bertelsmann) | 14 metrics | 15 / 27 | BTI by design excludes 12 established democracies |
| IBP Open Budget Survey | 2 metrics | 6 / 27 | Survey covers only select participating countries |

The remaining 73 non-AI indicators (from V-Dem, FH FIW, EIU, IDEA GSoD, CIVICUS, TI CPI, RSF, WJP) all pass the ≥19/27 threshold and are eligible for the composite.

### 2.4 Empirical decisions taken at Step 2

1. **20 AI indicators are composite-eligible.** They form the AI Readiness cross-sectional index layer.
2. **9 AI indicators are descriptive-only.** They appear in country profiles and dashboard snapshots but do not contribute to composite scoring.
3. **OECD AI Incidents Monitor** is excluded from the composite but included as a standalone panel variable in longitudinal regression (Method 1).
4. **73 non-AI indicators are composite-eligible.** BTI and IBP (16 metrics, 2 sources) are excluded from the composite due to structural coverage gaps.
5. **90 of 118 metrics have T ≥ 5 years** and are eligible for panel regression. The remaining 28 are cross-sectional only.

**Proceed to Step 3.**

---

## Step 3 — Data Imputation

**Status: COMPLETED — June 2026**
**Output file:** `step3_imputed_dataset.csv` (45,639 rows; saved to `/Final Project/`)

**Performed after:** Steps 1–2. **Performed before:** normalisation.

**Purpose:** fill eligible (MAR-tagged) missing values to create a complete rectangular dataset for each analysis layer.

**Methodological grounding:** JRC (2005) recommends multiple imputation over single imputation, and hot-deck (cluster-based) imputation over simple mean substitution. Oxford Insights GIRAI (2026) uses K-means clustering of countries into similar governance-profile groups, then imputes missing values from the cluster mean. Stanford GVT uses country mean across available years (simpler, acceptable for sparse temporal gaps). Multiple imputation is the gold standard but requires adequate observed data per indicator — this is not available for single-year indicators.

### 3.1 Imputation executed

**Rule 1 — Temporal interpolation (MAR_temporal):** the only imputation actually applied.

From Step 1, all 441 non-observed country × indicator combinations are classified MNAR (no imputation permissible) with the sole exception of the 81 WB GovTech temporal gaps. The Step 1 audit confirmed zero MAR_crosssectional cells, so Rules 2 (LOCF carry-forward) and Rule 3 (K-means cluster imputation) have no eligible cells to apply to.

**WB GovTech GTEI — 81 interpolated rows (27 countries × 3 missing years: 2021, 2023, 2024):**

Linear interpolation formula:
- Year 2021 (midpoint between 2020 and 2022): `v2021 = v2020 + (v2022 − v2020) × 0.5`
- Year 2023 (1/3 of way between 2022 and 2025): `v2023 = v2022 + (v2025 − v2022) × 0.333`
- Year 2024 (2/3 of way between 2022 and 2025): `v2024 = v2022 + (v2025 − v2022) × 0.667`

Interpolation is bounded by observed values — no extrapolation beyond 2025. All 81 imputed rows are tagged with `Source_Type = imputed_linear_interpolation`.

Sample result (Australia):

| Year | Value | Source |
|------|-------|--------|
| 2020 | 0.9344 | observed |
| **2021** | **0.8722** | **interpolated** |
| 2022 | 0.8099 | observed |
| **2023** | **0.8726** | **interpolated** |
| **2024** | **0.9353** | **interpolated** |
| 2025 | 0.9979 | observed |

### 3.2 Rules not applied (and why)

| Rule | Status | Reason |
|------|--------|--------|
| LOCF carry-forward | Not applied | No MAR_carryforward cells identified in Step 1 |
| K-means cluster imputation | Not applied | No MAR_crosssectional cells in dataset — all cross-sectional gaps are MNAR |
| No imputation for MNAR | Applied by default | 441 MNAR cells remain missing throughout pipeline |

### 3.3 Cross-driver indicator flag

During Step 3 execution, one indicator was identified as assigned to two different drivers in the dataset: `D4: Free private discussion (0-4)` (Freedom House FIW) appears under both T1/D2 (Information Environment Shocks) and T1/D5 (Polarization/Affective Tribalism). This reflects a deliberate cross-driver assignment from the original data compilation. In the composite score construction (Step 7), this indicator must be treated as a shared indicator and assigned to only one driver per composite calculation to avoid double-counting. Decision deferred to Step 7.

### 3.4 Summary

| Item | Count |
|------|-------|
| Rows in base dataset (final_CORDA_dataset.csv) | 45,558 |
| Imputed rows added (WB GovTech) | 81 |
| Rows in imputed dataset (step3_imputed_dataset.csv) | 45,639 |
| MNAR cells remaining (unimputed) | 441 |

All downstream steps (4–8) operate on `step3_imputed_dataset.csv`.

**Proceed to Step 4.**

---

## Step 4 — Min-Max Normalisation to 0–100

**Status: COMPLETED — June 2026**
**Output file:** `step4_normalised_dataset.csv` (45,639 rows; saved to `/Final Project/`)
**Schema change:** original `Value` column renamed to `Value_raw`; normalised scores stored in `Value`.

**Performed after:** Step 3. **Performed before:** internal consistency checks and weighting.

**Purpose:** bring all 118 indicators onto a common 0–100 scale before aggregation, so that indicators with large absolute ranges do not dominate the composite.

**Methodological grounding:** Min-max normalisation is the standard approach in Oxford Insights GIRAI (2026), Tortoise Global AI Index (2024), and is one of the two recommended normalisation methods in JRC (2005) alongside z-score standardisation. The choice between min-max and z-score is sensitivity-tested in Step 8. Global (rather than year-specific) reference points are used so that scores are comparable across time — as recommended by OECD AI Observatory Index (2026, Section 4.2).

### 4.1 Direction alignment — executed

Convention: **higher normalised score = more democratic / more AI-ready / less vulnerable**.

Seven indicators were identified as adverse-coded (higher raw value = worse for democracy) and reversed before normalisation using:
```
x_reversed = x_max_global − x + x_min_global
```

| Indicator | Why reversed |
|-----------|-------------|
| % AI Will Replace Job (Ipsos) | Higher % agreement = more economic anxiety/AI displacement exposure |
| OECD AI Incidents Monitor | Higher count = more deepfake/disinformation incidents = more exposed |
| RSF Press Freedom Score | RSF scale: lower number = more free press; reversed so higher = freer |
| v2x_corr: Political Corruption Index | Higher = more corruption = worse for democracy |
| v2x_neopat: Neopatrimonial Rule Index | Higher = more neopatrimonial rule = worse |
| v2caautmob: Mobilisation for Autocracy | Higher = more pro-autocracy mobilisation = worse |
| v2cacamps: Political Polarisation | Higher = more polarisation = worse |

All other 111 indicators were already coded so that higher = better for democracy and required no reversal.

**Note on V-Dem DSP variables:** v2smgovdom, v2smpardom, v2smpolsoc, v2smmefra, v2smpolhate are all V-Dem interval-scaled estimates where higher = better (e.g., higher v2smpolsoc = less societal polarisation). No reversal applied.

### 4.2 Global min-max normalisation — executed

Formula applied per indicator:
```
Value_normalised = (x_aligned − global_min_aligned) / (global_max_aligned − global_min_aligned) × 100
```

Global minimum and maximum computed across **all countries and all years** in the full panel (not within each year separately), ensuring temporal comparability of scores.

**Result:** All 45,639 normalised values lie strictly within [0, 100]. Zero NaN values. Zero constant-value indicators.

### 4.3 Spot-check validation

| Indicator | Country | Value_raw | Value (normalised) | Expected |
|-----------|---------|-----------|-------------------|----------|
| v2x_corr (reversed) | Australia 2025 | 0.029 (low corr.) | 97.2 | High ✓ |
| v2x_corr (reversed) | China 2024 | 0.550 (high corr.) | 42.4 | Low ✓ |
| RSF (reversed) | Netherlands 2013 | 6.48 (most free) | 100.0 | Highest ✓ |
| RSF (reversed) | Nigeria 2020 | 60+ (least free) | ~0 | Lowest ✓ |

### 4.4 Handling negative raw values

Several indicators had negative raw values (all V-Dem/DSP Bayesian interval estimates: e.g., v2smpolhate ranges −3.164 to +2.882). Negative values present no obstacle to min-max normalisation — the formula uses the observed global minimum as the floor regardless of sign. This is standard practice per JRC (2005, Section 5.2).

**Proceed to Step 5.**

---

## Step 5 — Internal Consistency Checks

**Status: COMPLETED — June 2026**
**Output files:** `step5_driver_summary.csv`, `step5_redundant_pairs.csv`, `step5_weak_pairs.csv`

**Performed after:** Step 4. **Performed before:** weighting in Step 6.

**Purpose:** test whether the indicators assigned to each driver measure a coherent underlying construct, identify redundant pairs that would double-count the same signal, and determine whether PCA or equal weighting is appropriate within each driver.

**Methodological grounding:** JRC (2005) and Oxford Insights GIRAI (2026) both require multivariate analysis (pairwise correlation and Cronbach's alpha) before aggregation. α ≥ 0.70 is the threshold for justified PCA weighting within a driver; α < 0.70 defaults to equal weighting. Pairs with r > 0.90 are flagged as highly redundant; pairs with r < 0.20 are flagged as weakly matched to the driver.

### 5.0 Critical pre-check: DSP variable duplication resolved

Before running consistency checks, a structural duplication was identified: five V-Dem/DSP variables (v2smgovdom, v2smmefra, v2smpolhate, v2smpolsoc, v2smpardom) appear in **both** the AI indicators layer (short names) and the non-AI indicators layer (full descriptive names) with **identical values**. Including both versions would artificially inflate internal consistency and double-count these variables in the composite.

**Resolution for composite construction:** Drop the AI short-name versions of v2smgovdom, v2smmefra, v2smpolhate, v2smpolsoc from the composite (retain the non-AI full-name versions). **Exception:** v2smpardom has no non-AI counterpart in the dataset → retain the AI version. This reduces composite-eligible metrics from 92 to **88**.

### 5.1 Driver-level results

| Driver | Total metrics (AI / non-AI) | CS N complete | Panel N | α (CS) | α (Panel) | Redundant pairs | Weighting decision |
|--------|---------------------------|--------------|---------|--------|-----------|----------------|-------------------|
| D1 Economic Inequality | 10 (3 / 7) | 17 | 351 | 0.941 | **0.963** | 2 | **PCA (panel)** |
| D2 Information Environment | 21 (3 / 18) | 20 | 81 | 0.943 | **0.980** | 15 | **PCA (panel)** |
| D3 Elite Defection | 21 (4 / 17) | 21 | 0 | **0.920** | N/A | 18 | **PCA (CS)** |
| D4 State Capacity | 27 (6 / 21) | 19 | 0 | **0.957** | N/A | 29 | **PCA (CS)** |
| D5 Polarization | 9 (0 / 9) | 27 | 459 | 0.088 | 0.309 | 0 | **Equal weighting** |

### 5.2 Driver-specific findings

**D1 — Economic Inequality / Relative Deprivation (α panel = 0.963 → PCA)**

High internal consistency confirmed. Two redundant pairs in the pooled panel:
- IDEA GSoD: Social Group Equality ↔ v2x_egal: Egalitarian Component (r = +0.924)
- v2x_egal: Egalitarian Component ↔ v2xeg_eqprotec: Equal Protection (r = +0.945)

Decision: use PCA loadings from pooled panel (N=351) as within-driver weights. The redundant V-Dem pairs (v2x_egal and its sub-indices) should be consolidated — retain v2x_egal (the composite) and drop v2xeg_eqprotec to avoid double-counting. Carry this decision forward to Step 6.

**D2 — Information Environment Shocks (α panel = 0.980 → PCA)**

Very high consistency. 15 redundant pairs, concentrated among three clusters:
- FH FIW D1 (free media) ↔ IDEA GSoD Freedom of Expression ↔ IDEA GSoD Freedom of Press ↔ v2meharjrn ↔ v2mecenefm (all r > 0.90) — these five indicators measure nearly identical content
- v2smgovdom ↔ v2smpardom (both DSP disinformation items — correlated but conceptually distinct AI-specific indicators; retain both)

Decision: PCA on pooled panel (N=81); PC1 loadings as weights. The highly correlated FH/IDEA/V-Dem media freedom cluster will naturally be collapsed by PCA — PC1 will represent the dominant "media freedom" dimension.

**D3 — Elite Defection / Intra-Elite Conflict (α CS = 0.920 → PCA, but panel N=0)**

High internal consistency at cross-sectional level. Panel N=0 because some non-AI indicators lack complete V-Dem coverage for all 17 metrics simultaneously. 18 redundant pairs, concentrated among:
- B1/B2/B3 (FH FIW political rights) ↔ IDEA GSoD Credible Elections ↔ EIU Electoral Pluralism (all r > 0.90) — all measure electoral competition quality
- 11 weak pairs involving the Tortoise Commercial Ecosystem indicators (r < 0.20 against all electoral indicators) — expected given conceptual distance between AI commercial ecosystem and party/election dynamics

Decision: PCA on cross-sectional complete cases (N=21). Note that Tortoise AI indicators (Companies, Funding scores) are weakly correlated with the electoral indicators — they measure a different facet of D3 (AI-driven elite capital concentration vs. electoral competition). Flag as a potential sub-score distinction in the research paper.

**D4 — State Capacity Erosion (α CS = 0.957 → PCA, but panel N=0)**

Highest internal consistency. 29 redundant pairs, notably:
- CIVICUS Rating ↔ CIVICUS Score (r = 0.971) — same data in two scales; drop one (retain Score)
- TI CPI ↔ WJP Factor 2 (Absence of Corruption) (r = 0.976) — near-identical measurement; retain CPI (broader coverage)
- TI CPI ↔ WJP Factor 6 (Regulatory Enforcement) (r = 0.963)
- TI CPI ↔ WJP Rule of Law Overall (r = 0.972)
- Government Strategy spend score weakly correlated (r < 0.20) with most governance quality indicators — reflects different facet (AI investment vs rule-of-law quality)

Decision: PCA on cross-sectional complete cases (N=19); consolidate exact duplicates (CIVICUS Rating/Score → keep Score only; WJP Overall subsumes sub-factors → use Overall only to avoid multicollinearity). Carry consolidation decisions to Step 6.

**D5 — Polarization / Affective Tribalism (α panel = 0.309 → Equal weighting)**

**Low internal consistency at both cross-sectional (α = 0.088) and pooled panel (α = 0.309) levels.** This indicates that the nine D5 indicators do not converge on a single polarisation construct — they measure distinct aspects. Notable weak pairs:
- EIU Democratic Culture ↔ v2smmefra (r = +0.053)
- IDEA GSoD Civil Society ↔ v2smpolsoc (r = −0.093)
- IDEA GSoD Civil Society ↔ v2caviol (r = −0.017)

This is methodologically important: D5 is theoretically the broadest driver (combining online polarisation, offline political violence, civil society strength, and democratic culture). The low alpha suggests these are distinct sub-dimensions rather than a single latent construct. **Equal weighting within D5** is the correct decision. Consider reporting D5 as two sub-scores in the research paper: (a) online polarisation sub-score and (b) democratic culture / civil society sub-score.

### 5.3 Indicator consolidations decided at Step 5

The following near-perfect duplicates will be removed from the composite in Step 6 to eliminate double-counting:

| Remove | Retain | r | Reason |
|--------|--------|---|--------|
| CIVICUS: Civic Space Rating (1=Closed to 5=Open) | CIVICUS: Civic Space Score (1-100) | 0.971 | Same data, two scales |
| WJP: Factor 2, 6, 7, 8 (sub-factors) | WJP: Rule of Law Index Overall Score | 0.963–0.976 | Sub-factors subsumed by overall |
| v2xeg_eqprotec: Equal Protection Index | v2x_egal: Egalitarian Component Index | 0.945 | Sub-index captured by composite |

### 5.4 Empirical decisions taken at Step 5

1. **PCA within D1, D2** using pooled panel loadings (N = 351 and 81 respectively).
2. **PCA within D3, D4** using cross-sectional loadings (N = 21 and 19 respectively). Panel PCA not available due to incomplete coverage across all metrics.
3. **Equal weighting within D5** — low alpha confirms indicators measure distinct sub-constructs; PCA is not justified.
4. **Three indicator consolidations** to eliminate near-duplicate double-counting (CIVICUS, WJP sub-factors, v2xeg_eqprotec).
5. **v2smpardom** (AI layer) retained as the only composite-eligible non-duplicated DSP variable in the AI layer.
6. **D5 sub-score split** flagged for the research paper: online polarisation vs. democratic culture / civil society.

**Proceed to Step 6.**

---

## Step 6 — Weighting

**Status: COMPLETED — June 2026**
**Output file:** `step6_weights.csv` (82 rows; saved to `/Final Project/`)

**Performed after:** Step 5. **Performed before:** composite score construction.

**Purpose:** assign relative weights to the 82 composite-eligible indicators within each driver, informed by Step 5 alpha results. Across-driver weighting is equal (20% per driver).

**Methodological grounding:** JRC (2005) recommends equal weighting as the default with PCA used conditionally when internal consistency is confirmed. Oxford Insights GIRAI (2026) uses PCA within each pillar. Tortoise (2024) downweights indicators with lower data coverage. Stanford GVT uses expert budget allocation. The approach here follows JRC (2005) and Oxford Insights: PCA where α ≥ 0.70, equal weighting otherwise, with a data-quality split for AI-only indicators.

### 6.0 Revision note

An earlier version of this step applied a 70/30 split — allocating 70% of each driver's weight to non-AI indicators via PCA and 30% equally to AI-only indicators. This ratio was not derived from any of the reference methodology sources (JRC 2005, Oxford Insights 2026, Tortoise 2024, Stanford GVT). It was removed. The primary specification is **equal weighting within all drivers**, consistent with JRC (2005, p. 82) as the recommended default for a new index. PCA results from Step 5 are retained as a sensitivity check (Test 6 in Step 8) and confirm that PCA-derived weights produce nearly identical rankings (τ = 0.97).

### 6.1 Indicator consolidations applied

Before weighting, three near-duplicate pairs identified in Step 5 were removed:

| Removed | Retained | r |
|---------|---------|---|
| CIVICUS: Civic Space Rating (1–5) | CIVICUS: Civic Space Score (1–100) | 0.971 |
| WJP: Factors 2, 6, 7, 8 (4 sub-factors) | WJP: Rule of Law Index Overall Score | 0.963–0.976 |
| v2xeg_eqprotec: Equal Protection Index | v2x_egal: Egalitarian Component Index | 0.945 |

This reduces composite-eligible metrics from 88 to **82** (D1: 9, D2: 21, D3: 21, D4: 22, D5: 9).

### 6.2 Within-driver weighting — executed

**Primary specification: equal weighting within all five drivers.**

All 82 composite-eligible indicators receive equal weight within their assigned driver. No PCA-derived weights are used in the primary composite. PCA results from Step 5 are used as a validation exercise (confirming internal consistency) and as a sensitivity test in Step 8.

| Driver | Metrics | Weight per indicator | Method |
|--------|---------|---------------------|--------|
| D1 Economic Inequality | 9 | **11.11%** | Equal (JRC 2005 primary spec) |
| D2 Information Environment | 21 | **4.76%** | Equal |
| D3 Elite Defection | 21 | **4.76%** | Equal |
| D4 State Capacity | 22 | **4.55%** | Equal |
| D5 Polarization | 9 | **11.11%** | Equal |

**Rationale for equal weighting over PCA:** JRC (2005, p. 82): "equal weighting is the most common solution and can be as defensible as any more complex approach, particularly when the index is new and the weighting assumptions are uncertain." Cross-sectional PCA for D3 (N=21 complete cases, 21 variables) and D4 (N=19, 22 variables) is statistically unreliable — the observation-to-variable ratio of approximately 1:1 is well below the N ≥ 10× per variable minimum for stable loadings. Panel PCA for D1 (N=351) and D2 (N=81) is more defensible but excludes AI-only indicators from the estimation. The sensitivity test in Step 8 confirms PCA-derived weights produce τ = 0.97 against equal weighting — the choice makes no material difference to country rankings.

**Direction correction (Tortoise Commercial Ecosystem):** The Commercial Ecosystem: Companies score and Funding score were identified as Exposure indicators — higher raw score = more AI concentration = higher elite capture risk = worse for democratic readiness. Both indicators were reversed (applied to `step4_normalised_dataset.csv` and all source files) before weighting, so that higher normalised score = less concentrated = better prepared.

### 6.4 Across-driver weighting

**Primary specification — equal weighting:**
Each of the five drivers contributes **20%** to the composite CORDA score.

**Sensitivity specifications tested in Step 8:**
- Specification A (Equal): D1 = D2 = D3 = D4 = D5 = 20% ← primary
- Specification B (Information-heavy): D2 = 30%, D1 = D3 = D4 = D5 = 17.5%
- Specification C (Capacity-heavy): D4 = 30%, D1 = D2 = D3 = D5 = 17.5%

### 6.5 Weight verification

All five driver weight vectors sum to exactly 1.0000. Full indicator weights are in `step6_weights.csv` with columns: Driver, Metric, Weight_raw, Weight_pct, Method, PC1_loading, PC1_var_explained, N_used.

**Proceed to Step 7.**

---

## Step 7 — Composite Score Construction

**Status: COMPLETED — June 2026**
**Output files:** `step7_cs_composite.csv` (27 rows), `step7_annual_composite.csv` (702 rows), `step7_annual_driver_scores.csv` (3,537 rows)

**Performed after:** Step 6. **Performed before:** sensitivity analysis.

**Purpose:** aggregate the weighted, normalised indicator values into driver-level scores and an overall composite country score.

**Methodological grounding:** JRC (2005, Section 6) distinguishes linear (arithmetic mean) from geometric mean aggregation. Linear aggregation (used here) assumes full compensability. The choice is sensitivity-tested in Step 8 against geometric mean.

### 7.1 Aggregation formulas

**Driver score for country i (partial weighting):**
```
Driver_score_i = Σ(w_j × value_ij) / Σ(w_j for observed indicators only)
```
Partial weighting is used so countries missing some indicators within a driver still receive a driver score, weighted by the indicators available. A country with all indicators missing for a driver receives a missing (NaN) driver score.

**Composite CORDA score for country i:**
```
CORDA_score_i = mean(Driver_score_d1, Driver_score_d2, ..., Driver_score_d5)
```
Equal weighting across drivers (primary specification). Countries missing ≥ 3 driver scores are excluded from the composite ranking.

### 7.2 Two composite products

**Product A — Cross-sectional composite (step7_cs_composite.csv):**
Uses the most recent available year per indicator (ranging from 2021 for some WB GovTech interpolated cells to 2026 for CAIDP Q9; most indicators use 2024 or 2025). Represents the 2023–2025 AI readiness snapshot for all 27 countries. All 27 countries receive all 5 driver scores.

**Product B — Annual composite panel (step7_annual_composite.csv):**
Driver scores computed for every country × year from 2000 to 2025 (26 years). Year 2026 excluded — only CAIDP Q9 has 2026 data, making a single-indicator driver score meaningless as a composite input. Only country-years with N_drivers ≥ 3 are retained (all 702 country-year rows meet this criterion). Provides the longitudinal democratic readiness trajectory for panel regression (Method 1), latent growth curve modelling (Method 2), and DiD analysis (Method 3).

### 7.3 Cross-sectional composite results (2023–2025)

*Revised results after (a) Tortoise Commercial Ecosystem direction correction and (b) removal of fabricated 70/30 weighting split — equal weighting within all drivers.*

All 27 countries receive a full composite score with all 5 driver scores available.

| Rank | Country | CORDA Score |
|------|---------|------------|
| 1 | Denmark | 86.2 |
| 2 | Sweden | 81.1 |
| 3 | Germany | 78.8 |
| 4 | Netherlands | 78.3 |
| 5 | Japan | 74.1 |
| 6 | Australia | 73.9 |
| 7 | Canada | 73.6 |
| 8 | United Kingdom | 73.3 |
| 9 | New Zealand | 71.2 |
| 10 | France | 70.7 |
| 11 | Taiwan | 69.6 |
| 12 | Chile | 68.7 |
| 13 | South Korea | 67.4 |
| 14 | Poland | 64.9 |
| 15 | United States | 63.8 |
| 16 | Israel | 63.3 |
| 17 | Singapore | 60.1 |
| 18 | Brazil | 58.3 |
| 19 | Ghana | 57.2 |
| 20 | South Africa | 56.7 |
| 21 | Indonesia | 48.7 |
| 22 | India | 46.1 |
| 23 | Mexico | 45.8 |
| 24 | Nigeria | 43.5 |
| 25 | United Arab Emirates | 37.1 |
| 26 | Bangladesh | 34.0 |
| 27 | China | 28.6 |

### 7.4 Face validity — known backslider trajectories

Cross-checking against countries with documented democratic backsliding (Brazil under Bolsonaro, India under Modi, Poland under PiS):

| Country | 2015 | 2020 | 2024 | Direction |
|---------|------|------|------|-----------|
| Brazil | 64.2 | 51.6 | 59.1 | Declined 2015–2020, partial recovery post-2022 ✓ |
| India | 53.4 | 47.5 | 46.5 | Continuous decline ✓ |
| Poland | 73.5 | 63.8 | 65.5 | Declined under PiS, partial recovery after 2023 elections ✓ |

All three trajectories are directionally consistent with established democracy index findings, supporting face validity of the CORDA composite.

### 7.5 2026 data excluded from composite

CAIDP Q9 has 2026 edition data, but no other indicator extends to 2026. Including 2026 in the annual composite would produce single-indicator driver scores that are not comparable to composite scores in other years. Year 2026 is excluded from `step7_annual_composite.csv`. CAIDP Q9's 2026 values are retained in the dataset for descriptive reporting only.

**Proceed to Step 8.**

---

## Step 8 — Sensitivity and Robustness Analysis

**Status: COMPLETED — June 2026**
**Output file:** `step8_sensitivity_summary.csv`

**Performed after:** Step 7. **Required before:** publication of rankings.

**Purpose:** test whether country rankings change materially under alternative methodological choices.

**Methodological grounding:** JRC (2005, Chapter 8) requires uncertainty and sensitivity analysis for all composite indicators. Oxford Insights GIRAI (2026) reports that equal weighting produces nearly identical rankings to PCA weighting as their robustness confirmation.

*Revised results after (a) Tortoise Commercial Ecosystem direction correction and (b) removal of fabricated 70/30 weighting split.*

### 8.1 Results summary

| Test | Kendall τ vs primary | Countries shifting >5 ranks | Verdict |
|------|---------------------|----------------------------|---------|
| T1: Z-score vs min-max normalisation | 0.9829 | 0 | Robust ✓ |
| T2: Geometric vs linear aggregation | 0.7835 | 1 (New Zealand) | **Sensitive — flag** |
| T3b: Spec B — D2=30% (Info-heavy) | 0.9487 | 0 | Robust ✓ |
| T3c: Spec C — D4=30% (Capacity-heavy) | 0.9829 | 0 | Robust ✓ |
| T4: No imputation (WB GovTech observed only) | **1.0000** | 0 | Fully robust ✓ |
| T5: Borderline Ipsos indicators excluded | **1.0000** | 0 | Fully robust ✓ |
| T6 (new): PCA weights vs equal weights | 0.9715 | 0 | Robust ✓ |
| **Kendall's W across Spec A/B/C** | **0.9948** | — | **Equal weighting confirmed** |

### 8.2 Test 1 — Normalisation: z-score vs min-max

Kendall τ = 0.9829. No country shifts more than 5 ranks. Min-max and z-score (rescaled to 0–100) produce near-identical rankings. Min-max is retained as the primary method for its intuitive 0–100 interpretability and alignment with Oxford Insights GIRAI (2026) and Tortoise (2024).

### 8.3 Test 2 — Aggregation: geometric vs linear mean

Kendall τ = 0.7835. **New Zealand** shifts from rank 9 (primary) to rank 19 under geometric aggregation — a 10-rank drop. This is the largest instability in the entire sensitivity analysis.

Investigation confirmed the cause: New Zealand's D5 (Polarization/Affective Tribalism) driver score is 51.8 in 2024, while its other four drivers range from 67 to 85. Geometric mean penalises this asymmetry severely — the "weakest-link" effect amplifies the D5 gap that arithmetic mean smooths over. Sweden shows a smaller version of the same pattern (D5 = 63.3, others 79–91).

This finding reinforces the D5 construct validity concern from Step 5 (α = 0.088). Countries with uneven driver profiles are disproportionately affected by aggregation method choice, and the effect is largest for D5 specifically. Reporting the geometric mean alongside the primary linear score for New Zealand and Sweden is recommended.

**Decision:** retain linear aggregation as primary. Report geometric in robustness appendix. Dashboard toggle available.

### 8.4 Test 3 — Driver weighting specifications

Kendall's W = **0.9948** across all three specifications. Equal weighting confirmed as robust. No country shifts more than 5 ranks regardless of whether D2 or D4 is upweighted. This validates the primary equal-weighting specification.

### 8.5 Test 4 — Imputation sensitivity

Kendall τ = 1.0000. The WB GovTech temporal interpolation (81 cells) has zero effect on rankings. Confirmed fully robust.

### 8.6 Test 5 — Borderline indicator exclusion

Kendall τ = 1.0000. Excluding both Ipsos indicators (20/27 coverage) has zero effect on rankings. The composite is fully insensitive to the inclusion of these marginal-coverage indicators.

### 8.7 Test 6 (new) — PCA-derived weights vs equal weights

Kendall τ = 0.9715. No country shifts more than 5 ranks when PCA loadings (panel for D1/D2, cross-sectional for D3/D4) replace equal weights. This confirms the decision to use equal weighting as the primary specification: PCA adds complexity without changing substantive conclusions.

### 8.8 Overall robustness verdict

The CORDA composite is robust to all tested methodological alternatives except geometric mean aggregation, which causes a 10-rank drop for New Zealand driven entirely by its D5 score. The primary specification (min-max normalisation, linear aggregation, equal within-driver weighting, equal across-driver weighting) is confirmed as the most defensible and transparent choice.

Two countries — **New Zealand** and **Sweden** — should carry a published note that their rankings are sensitive to aggregation method, and their D5 driver score should be reported alongside their composite. All sensitivity results are in `step8_sensitivity_summary.csv`.

**Pipeline complete. Proceed to analytical methods (Methods 1–5).**

---

## Analytical Methods for Empirical Outputs

The following methods are used for the empirical analyses featured in the research paper and interactive dashboard. They replace ARIMA forecasting, which is methodologically infeasible given the 2–3-year observed window for AI-specific indicators.

### Method 1 — Panel Regression / Two-Way Fixed Effects (primary empirical method)

**Research question answered:** Do higher AI exposure scores predict deterioration in democratic health outcomes, controlling for country-level heterogeneity and global time trends?

**Data used:** Non-AI democratic health indicators (2000–2025, 27 countries) as the outcome variables; AI indicator cross-sectional scores (2023–2025) as the explanatory variables. The AI indicators are entered as time-invariant (or slow-moving) country-level covariates.

**Specification:**
```
Y_it = α_i + γ_t + β × AI_Exposure_i + ε_it
```
where Y_it is the democratic health indicator for country i in year t, α_i is the country fixed effect, γ_t is the year fixed effect, and AI_Exposure_i is the country's composite AI Exposure score. The coefficient β estimates the within-country association between AI exposure level and democratic health, net of all time-invariant country characteristics and all global-year shocks.

**Software:** R (`plm` package) or Python (`linearmodels` package).

**Reporting:** Coefficient estimates with heteroskedasticity-robust standard errors clustered at the country level, alongside F-tests of joint significance. Hausman test to confirm fixed effects over random effects.

### Method 2 — Latent Growth Curve Modelling (structural validation)

**Research question answered:** Do AI exposure and preparedness scores predict the rate at which countries' democratic health trajectories are improving or deteriorating?

**Data used:** Non-AI democratic health indicators as the longitudinal outcome; AI composite scores as time-invariant predictors of growth curve parameters.

**Specification:** A two-level growth model estimates each country's democracy intercept (level in 2000) and slope (rate of change 2000–2025) as random effects, then regresses those latent parameters on the AI driver scores. A steeper negative slope on the democracy outcome, predicted by a higher AI Exposure score, is the expected finding under the project's theoretical model.

**Rationale for inclusion:** LGM directly tests whether the index captures what the theory predicts — that AI exposure is associated with accelerating democratic deterioration. This belongs in the research paper's structural validation section.

**Software:** R (`lavaan` package) or Python (`semopy`).

### Method 3 — Difference-in-Differences (AI amplification test)

**Research question answered:** Did democratic health deteriorate faster in high-AI-exposure countries after 2023 (post-LLM era) relative to the pre-2023 period, compared to low-AI-exposure countries?

**Data used:** Non-AI democratic health indicators (2000–2025); AI Exposure score to define treatment (above median) vs control (below median) groups.

**Specification:**
```
Y_it = α + β₁ × Post_t + β₂ × HighExposure_i + β₃ × (Post_t × HighExposure_i) + ε_it
```
where Post_t = 1 for years 2023–2025, HighExposure_i = 1 for countries above the median composite AI Exposure score. The coefficient β₃ is the DiD estimator — the differential change in democratic health in high-exposure countries after the AI era began.

**Assumption check:** Parallel trends assumption must be tested and reported: democratic health trends in treatment and control countries must be statistically indistinguishable in the pre-period (2000–2022).

### Method 4 — Scenario-Based Conditional Projection (2030 trajectories for the dashboard)

**Research question answered:** Given observed AI exposure levels and the estimated regression relationship between AI exposure and democratic health change, what democratic health trajectories are implied by 2030 under low, medium, and high AI-impact scenarios?

**Procedure:**
1. Estimate the two-way fixed effects regression from Method 1 on the full 2000–2025 panel.
2. Using the estimated β coefficients, project democratic health forward to 2030 under three scenarios:
   - **Low scenario:** AI exposure scores remain at 2025 levels (no further increase)
   - **Medium scenario:** AI exposure scores increase by 10% per year from 2025 (linear extrapolation of recent trend)
   - **High scenario:** AI exposure scores increase by 20% per year from 2025
3. Report projected 2030 ranges as confidence intervals, not point estimates. Explicitly label as "conditional projections" not forecasts.

**Dashboard presentation:** Each country's 2030 projection is shown as a shaded range (low–high scenario band) overlaid on the observed historical democratic health trend line.

**Rationale for replacing ARIMA:** ARIMA requires T ≥ 5 observations per country per indicator for stable parameter estimation, with T ≥ 10–20 for credible long-horizon forecasting. The AI-specific indicators have T = 1–3 at most. Running ARIMA on a 3-point series and projecting to 2030 would produce confidence intervals too wide to be analytically meaningful and would be challenged by reviewers. Scenario-based projection via regression coefficients is honest about its assumptions and is methodologically analogous to IPCC climate projection practice.

### Method 5 — Synthetic Control / K-Nearest Neighbour Matching (case validation)

**Research question answered:** For countries known to have experienced AI-amplified democratic backsliding (Hungary, Turkey, Brazil 2019–2022), does the CORDA index predict their trajectory better than a counterfactual constructed from similar countries that did not backslide?

**Procedure:** The synthetic control method constructs a weighted combination of control countries (those without major democratic backsliding) that matches the pre-treatment trajectory of each case country on democratic health indicators. The post-treatment divergence between the case and its synthetic control is the estimated treatment effect of AI-amplified backsliding.

**This method is used exclusively in the research paper** for the validation section, not on the dashboard. It is not a forecasting method.

---

## Deliverable-Specific Methodology

### The 2025 Cross-Sectional Report

**Inputs:** All indicators with 2024 or 2025 data passing the strict missingness threshold (≥ 19 / 27 countries covered).

**Pipeline:** Steps 1 → 2 → 3 (cross-sectional K-means imputation only) → 4 → 5 → 6 → 7 → 8.

**Output:** Country scores on each of the five drivers and an overall CORDA composite score, ranked 1–27. Driver-level Exposure sub-score and Preparedness sub-score for each country. Supplementary indicator-level profiles for all 29 AI indicators, including those excluded from the composite (reported descriptively with country coverage noted).

**Benchmark comparisons:** Cross-reference CORDA rankings with V-Dem Liberal Democracy Index, Freedom House FIW, and EIU Democracy Index rankings for the same year as a face-validity check. High CORDA risk scores should correspond to lower scores on established democracy indices for countries known to have backslid.

### The Interactive Dashboard

**Longitudinal trend layer:** Shows the five DSP/V-Dem variables (2000–2025) and selected non-AI indicators as time-series trend lines. Shows the scenario-based 2030 projection as a shaded range beyond 2025. Does not present single-year AI indicators as trend lines.

**Cross-sectional snapshot layer:** Shows all 29 AI indicators for the most recent available year as maps, bar charts, or radar charts per country. Single-year indicators are labelled with their year (e.g., "2024 data") and are not extrapolated.

**Weighting toggle:** Allows users to switch between equal weighting (default) and z-score normalisation / geometric aggregation alternatives, consistent with the Stanford GVT's user-adjustable weight feature.

### The Research Paper

**Empirical structure:**
1. Index construction and measurement validity (Steps 1–8 above; CFA structural validation using pooled panel)
2. Cross-sectional analysis: country scores and distribution of CORDA index by region and regime type
3. Panel regression: association between AI exposure and democratic health trends (Method 1)
4. AI amplification test: DiD analysis pre/post 2023 (Method 3)
5. Trajectory modelling: LGM of democracy slopes predicted by driver scores (Method 2)
6. Case validation: synthetic control analysis for Hungary, Turkey, Brazil (Method 5)
7. Conditional projections to 2030 under three scenarios (Method 4)

---

## Limitations

1. **Small country N:** 27 countries is below the threshold for stable PCA and CFA estimation at the cross-sectional level. Pooled panel data is used to stabilise factor analytic results, but this trades spatial for temporal variation and may conflate cross-sectional and longitudinal variation in the factor structure.

2. **Short AI indicator time series:** The majority of AI-specific indicators (18 of 29) are single-year cross-sections. Time-series analysis and forecasting cannot be run on these indicators. This limits the CORDA index's ability to detect within-country change in AI governance capacity and restricts causal inference about AI's dynamic effects on democracy.

3. **MNAR missingness for GIRAI and survey-based indicators:** Bangladesh, Denmark, Israel, and Sweden cannot be scored on five GIRAI-based indicators. Several survey-based indicators exclude Middle Eastern, African, and Southeast Asian countries. These gaps are systematic and not imputable; they create a geographic coverage bias toward Western, high-income democracies.

4. **Freedom House Freedom on the Net absent:** This source requires a formal institutional data request to research@freedomhouse.org. It is absent from the current dataset. It would directly operationalise D2 (Information Environment) and its absence leaves that driver with thinner internet-freedom coverage.

5. **Tortoise sub-pillar aggregation:** The four Tortoise indicators in the dataset are sub-pillar aggregated scores, not the raw underlying indicators (e.g., "Commercial Ecosystem: Companies score" aggregates seven Crunchbase metrics). This introduces aggregation decisions by Tortoise that the CORDA project cannot verify or decompose.

6. **Ordinal CAIDP Q9 treated as continuous:** The CAIDP Algorithmic Transparency Law indicator (0/1/2 ordinal) is treated as continuous in PCA and composite score calculations. This is a pragmatic simplification noted as a limitation.

7. **Value scale heterogeneity before normalisation:** The 117 indicators span five distinct scales (0–1, 0–100, −5 to +5 latent, counts 0–∞, ordinal 0/1/2). Min-max normalisation resolves this post-Step 4, but the direction alignment check in Step 4 must be performed rigorously to avoid incorrectly coded indicators contaminating the composite.

---

## References

Besley, T. & Persson, T. (2011). *Pillars of Prosperity*. Princeton University Press.

Fukuyama, F. (2011). *The Origins of Political Order*. Farrar, Straus and Giroux.

Goldstone, J. (1991). *Revolution and Rebellion in the Early Modern World*. University of California Press.

Guriev, S. & Treisman, D. (2022). *Spin Dictators*. Princeton University Press.

Iyengar, S. et al. (2019). The Origins and Consequences of Affective Polarization in the United States. *Annual Review of Political Science*, 22, 129–146.

JRC / Nardo, M., Saisana, M., Saltelli, A., & Tarantola, S. (2005). *Tools for Composite Indicators Building*. EUR 21682 EN. European Commission Joint Research Centre. https://publications.jrc.ec.europa.eu/repository/handle/JRC31473

Levitsky, S. & Ziblatt, D. (2018). *How Democracies Die*. Crown Publishing.

Little, R.J.A. & Rubin, D.B. (2002). *Statistical Analysis with Missing Data* (2nd ed.). Wiley.

Maslej, N. et al. (2024). *The Global AI Vibrancy Tool*. Stanford HAI. arXiv:2412.04486.

Oxford Insights. (2026). *Government AI Readiness Index 2025: Methodology Report*. https://oxfordinsights.com/wp-content/uploads/2026/01/Methodology-Report-2025-1.pdf

Piketty, T. (2014). *Capital in the Twenty-First Century*. Harvard University Press.

Prat, A. & Strömberg, D. (2013). The Political Economy of Mass Media. *Advances in Economics and Econometrics*, 2, 135–187.

Turchin, P. (2016). *Ages of Discord*. Beresta Books.

Tortoise Media. (2024). *The Global Artificial Intelligence Index: Methodology Report*. https://www.tortoisemedia.com/_app/immutable/assets/AI-Methodology-2409.BGTLUPC-.pdf

Acemoglu, D. & Robinson, J.A. (2006). *Economic Origins of Dictatorship and Democracy*. Cambridge University Press.

Abramowitz, A. (2018). *The Great Alignment*. Yale University Press.

---

*End of CORDA Methodology v1.0*
