"""
CORDA Democracy — BTI + IBP Extractor
======================================
Run after downloading:
  bti.xlsx  → already downloaded via curl
  ibp.xlsx  → already downloaded via curl
  idea_gsod.xlsx → download manually from idea.int/gsod-indices/dataset-resources

Usage:
    python3 extract_bti_ibp_idea.py
"""

import os, sys, warnings
import pandas as pd

warnings.filterwarnings('ignore')

SCRIPT_DIR  = os.path.dirname(os.path.abspath(__file__))
OUTPUT_CSV  = os.path.join(SCRIPT_DIR, 'non_ai_democracy.csv')

CORDA_ISO3 = {
    'AUS','BGD','BRA','CAN','CHL','CHN','DNK','FRA','DEU','GHA','IND','IDN',
    'ISR','JPN','MEX','NLD','NZL','NGA','POL','SGP','ZAF','KOR','SWE','TWN',
    'ARE','GBR','USA'
}
ISO3_NAME = {
    'AUS':'Australia','BGD':'Bangladesh','BRA':'Brazil','CAN':'Canada',
    'CHL':'Chile','CHN':'China','DNK':'Denmark','FRA':'France','DEU':'Germany',
    'GHA':'Ghana','IND':'India','IDN':'Indonesia','ISR':'Israel','JPN':'Japan',
    'MEX':'Mexico','NLD':'Netherlands','NZL':'New Zealand','NGA':'Nigeria',
    'POL':'Poland','SGP':'Singapore','ZAF':'South Africa','KOR':'South Korea',
    'SWE':'Sweden','TWN':'Taiwan','ARE':'United Arab Emirates',
    'GBR':'United Kingdom','USA':'United States'
}
DRIVER_ORDER = {
    'T1/D1 (Economic Inequality/Relative Deprivation)':0,
    'T1/D2 (Information Environment Shocks)':1,
    'T1/D3 (Elite Defection/Intra-Elite Conflict)':2,
    'T1/D4 (State Capacity Erosion)':3,
    'T1/D5 (Polarization/Affective Tribalism)':4,
}

def make_row(year, iso3, metric, value, driver, dataset, source, src_file, src_year):
    return {
        'Year': int(year), 'Country': ISO3_NAME.get(iso3, iso3), 'ISO3': iso3,
        'Driver': driver, 'Metric': metric,
        'Value': round(float(value), 6),
        'Dataset': dataset, 'Source': source,
        'Source_File': src_file, 'Source_Type': 'xlsx', 'Source_Year': int(src_year)
    }

all_new_rows = []

# ══════════════════════════════════════════════════════════════════════════════
# 1.  BTI  (Bertelsmann Transformation Index, 2006–2026, biennial)
# ══════════════════════════════════════════════════════════════════════════════
BTI_PATH = os.path.join(SCRIPT_DIR, 'bti.xlsx')

# BTI indicators and their driver assignments
BTI_COLS = {
    # col_header_fragment : (metric_label, driver)
    'Q1 | Stateness':
        ('BTI Q1: Stateness (1-10)', 'T1/D4 (State Capacity Erosion)'),
    'Q1.1 | Monopoly on the use of force':
        ('BTI Q1.1: Monopoly on use of force (1-10)', 'T1/D4 (State Capacity Erosion)'),
    'Q1.2 | State identity':
        ('BTI Q1.2: State identity (1-10)', 'T1/D4 (State Capacity Erosion)'),
    'Q1.3 | No interference of religious dogmas':
        ('BTI Q1.3: No interference of religious dogmas (1-10)', 'T1/D4 (State Capacity Erosion)'),
    'Q1.4 | Basic administration':
        ('BTI Q1.4: Basic administration (1-10)', 'T1/D4 (State Capacity Erosion)'),
    'Q2.4 | Freedom of expression':
        ('BTI Q2.4: Freedom of expression (1-10)', 'T1/D2 (Information Environment Shocks)'),
    'Q4.1 | Performance of democratic institutions':
        ('BTI Q4.1: Performance of democratic institutions (1-10)', 'T1/D4 (State Capacity Erosion)'),
    'Q5 | Political and Social Integration':
        ('BTI Q5: Political and Social Integration (1-10)', 'T1/D5 (Polarization/Affective Tribalism)'),
    'Q5.1 | Party system':
        ('BTI Q5.1: Party system (1-10)', 'T1/D3 (Elite Defection/Intra-Elite Conflict)'),
    'Q5.2 | Interest groups':
        ('BTI Q5.2: Interest groups (1-10)', 'T1/D3 (Elite Defection/Intra-Elite Conflict)'),
    'Q10 | Welfare Regime':
        ('BTI Q10: Welfare Regime (1-10)', 'T1/D1 (Economic Inequality/Relative Deprivation)'),
    'Q10.2 | Equal opportunity':
        ('BTI Q10.2: Equal opportunity (1-10)', 'T1/D1 (Economic Inequality/Relative Deprivation)'),
    'Q14 | Steering Capability':
        ('BTI Q14: Steering Capability / Governance (1-10)', 'T1/D4 (State Capacity Erosion)'),
    'G | Governance Index':
        ('BTI G: Governance Index (1-10)', 'T1/D4 (State Capacity Erosion)'),
}

if os.path.exists(BTI_PATH):
    xl = pd.ExcelFile(BTI_PATH)
    bti_sheets = [s for s in xl.sheet_names if s.startswith('BTI 20') and 'old' not in s]
    bti_count = 0

    for sheet in bti_sheets:
        year_str = sheet.replace('BTI ', '').strip()
        try:
            year = int(year_str)
        except:
            continue

        df = pd.read_excel(BTI_PATH, sheet_name=sheet, header=None)
        headers = df.iloc[0].tolist()

        # Build col index → metric mapping
        col_to_metric = {}
        for ci, h in enumerate(headers):
            h_str = str(h).strip()
            for frag, (metric, driver) in BTI_COLS.items():
                if frag in h_str:
                    col_to_metric[ci] = (metric, driver)
                    break

        if not col_to_metric:
            continue

        for _, row in df.iloc[1:].iterrows():
            country_name = str(row.iloc[0]).strip()
            # Map BTI country names to ISO3
            BTI_NAME_MAP = {
                'Australia':'AUS','Bangladesh':'BGD','Brazil':'BRA','Canada':'CAN',
                'Chile':'CHL','China':'CHN','Denmark':'DNK','France':'FRA',
                'Germany':'DEU','Ghana':'GHA','India':'IND','Indonesia':'IDN',
                'Israel':'ISR','Japan':'JPN','Mexico':'MEX','Netherlands':'NLD',
                'New Zealand':'NZL','Nigeria':'NGA','Poland':'POL','Singapore':'SGP',
                'South Africa':'ZAF','South Korea':'KOR','Sweden':'SWE','Taiwan':'TWN',
                'United Arab Emirates':'ARE','United Kingdom':'GBR','United States':'USA',
                'Korea, South':'KOR','Korea (South)':'KOR','Republic of Korea':'KOR',
            }
            iso3 = BTI_NAME_MAP.get(country_name)
            if not iso3 or iso3 not in CORDA_ISO3:
                continue

            for ci, (metric, driver) in col_to_metric.items():
                val = row.iloc[ci]
                try:
                    val = float(val)
                    if pd.isna(val): continue
                except:
                    continue
                all_new_rows.append(make_row(
                    year, iso3, metric, val, driver,
                    'BTI - Bertelsmann Transformation Index',
                    'Bertelsmann Stiftung',
                    'https://bti-project.org/en/downloads',
                    year
                ))
                bti_count += 1

    print(f"✓ BTI: {bti_count:,} rows extracted ({len(bti_sheets)} editions)")
else:
    print(f"⚠ BTI file not found: {BTI_PATH}")

# ══════════════════════════════════════════════════════════════════════════════
# 2.  IBP Open Budget Survey  (2006–2025, biennial)
# ══════════════════════════════════════════════════════════════════════════════
IBP_PATH = os.path.join(SCRIPT_DIR, 'ibp.xlsx')

if os.path.exists(IBP_PATH):
    df_ibp = pd.read_excel(IBP_PATH, sheet_name='OBS_Data_2006-2025', header=None)
    ibp_headers = df_ibp.iloc[0].tolist()
    df_ibp.columns = ibp_headers
    df_ibp = df_ibp.iloc[1:].reset_index(drop=True)
    df_ibp = df_ibp[df_ibp['ISO'].isin(CORDA_ISO3)].copy()

    ibp_count = 0
    IBP_METRICS = {
        'obi':          ('IBP: Open Budget Index / Transparency Score (0-100)', 'T1/D4 (State Capacity Erosion)'),
        'legover':      ('IBP: Legislative Oversight Score (0-100)', 'T1/D4 (State Capacity Erosion)'),
        'saiover':      ('IBP: Supreme Audit Institution Oversight Score (0-100)', 'T1/D4 (State Capacity Erosion)'),
        'oversight_obi':('IBP: Overall Budget Oversight Score (0-100)', 'T1/D4 (State Capacity Erosion)'),
        'pubpart':      ('IBP: Public Participation Score (0-100)', 'T1/D4 (State Capacity Erosion)'),
    }

    for col, (metric, driver) in IBP_METRICS.items():
        if col not in df_ibp.columns:
            continue
        for _, row in df_ibp.iterrows():
            iso3 = str(row['ISO']).strip()
            if iso3 not in CORDA_ISO3: continue
            try:
                yr  = int(float(row['year']))
                val = float(row[col])
                if pd.isna(val): continue
            except:
                continue
            all_new_rows.append(make_row(
                yr, iso3, metric, val, driver,
                'IBP Open Budget Survey',
                'International Budget Partnership',
                'https://internationalbudget.org/open-budget-survey/download',
                2025
            ))
            ibp_count += 1

    print(f"✓ IBP: {ibp_count:,} rows extracted")
else:
    print(f"⚠ IBP file not found: {IBP_PATH}")

# ══════════════════════════════════════════════════════════════════════════════
# 3.  IDEA GSoD  (optional — run if idea_gsod.xlsx is present)
# ══════════════════════════════════════════════════════════════════════════════
IDEA_PATH = next(
    (os.path.join(SCRIPT_DIR, f) for f in ['idea_gsod.csv','idea_gsod.xlsx']
     if os.path.exists(os.path.join(SCRIPT_DIR, f))),
    os.path.join(SCRIPT_DIR, 'idea_gsod.csv')
)

if os.path.exists(IDEA_PATH):
    if IDEA_PATH.endswith('.csv'):
        df_idea = pd.read_csv(IDEA_PATH, low_memory=False)
    else:
        xl_idea = pd.ExcelFile(IDEA_PATH)
        print(f"IDEA GSoD sheets: {xl_idea.sheet_names[:5]}")
        for sheet in xl_idea.sheet_names:
            try:
                df_idea = pd.read_excel(IDEA_PATH, sheet_name=sheet, header=0)
                if any(c.lower() in ['iso3c','country_code','iso','iso3'] for c in df_idea.columns):
                    break
            except:
                continue

    # Normalise column names
    df_idea.columns = [str(c).strip().lower() for c in df_idea.columns]
    print(f"IDEA GSoD: {len(df_idea):,} rows loaded")

    iso_col  = next((c for c in df_idea.columns if c in ['iso3c','country_code','iso','iso3','code']), None)
    year_col = next((c for c in df_idea.columns if c == 'year' or 'year' in c), None)

    IDEA_METRICS = {
        'soc_grp_equal_est': ('IDEA GSoD: Social Group Equality (0-1)', 'T1/D1 (Economic Inequality/Relative Deprivation)'),
        'free_express_est':  ('IDEA GSoD: Freedom of Expression (0-1)', 'T1/D2 (Information Environment Shocks)'),
        'free_press_est':    ('IDEA GSoD: Freedom of the Press (0-1)',  'T1/D2 (Information Environment Shocks)'),
        'free_parties_est':  ('IDEA GSoD: Free Political Parties (0-1)','T1/D3 (Elite Defection/Intra-Elite Conflict)'),
        'elected_gov_est':   ('IDEA GSoD: Elected Government (0-1)',    'T1/D3 (Elite Defection/Intra-Elite Conflict)'),
        'civil_soc_est':     ('IDEA GSoD: Civil Society (0-1)',         'T1/D5 (Polarization/Affective Tribalism)'),
        'cred_elect_est':    ('IDEA GSoD: Credible Elections (0-1)',    'T1/D3 (Elite Defection/Intra-Elite Conflict)'),
    }

    if iso_col and year_col:
        df_idea_corda = df_idea[df_idea[iso_col].isin(CORDA_ISO3)]
        idea_count = 0
        for col, (metric, driver) in IDEA_METRICS.items():
            if col not in df_idea.columns: continue
            for _, row in df_idea_corda.iterrows():
                try:
                    val = float(row[col])
                    if pd.isna(val): continue
                    yr  = int(row[year_col])
                    iso3 = str(row[iso_col]).strip()
                except:
                    continue
                all_new_rows.append(make_row(
                    yr, iso3, metric, val, driver,
                    'IDEA GSoD - Global State of Democracy',
                    'International IDEA',
                    'https://www.idea.int/gsod-indices/dataset-resources',
                    2025
                ))
                idea_count += 1
        print(f"✓ IDEA GSoD: {idea_count:,} rows extracted")
    else:
        print(f"⚠ IDEA GSoD: could not identify ISO/year columns. Columns: {list(df_idea.columns[:10])}")
else:
    print("⚠ IDEA GSoD file not found (idea_gsod.xlsx) — skipping.")
    print("  Download from: https://www.idea.int/gsod-indices/dataset-resources")

# ══════════════════════════════════════════════════════════════════════════════
# 4.  Merge into non_ai_democracy.csv
# ══════════════════════════════════════════════════════════════════════════════
if not all_new_rows:
    print("\nNo rows extracted — nothing to merge.")
    sys.exit(0)

df_new = pd.DataFrame(all_new_rows)

if os.path.exists(OUTPUT_CSV):
    df_existing = pd.read_csv(OUTPUT_CSV)
    # Remove any rows whose metrics are about to be replaced (idempotent)
    new_metrics = set(df_new['Metric'].unique())
    df_existing_filtered = df_existing[~df_existing['Metric'].isin(new_metrics)]
    n_replaced = len(df_existing) - len(df_existing_filtered)
    if n_replaced > 0:
        print(f"  Replaced {n_replaced:,} existing rows for these metrics")
    df_combined = pd.concat([df_existing_filtered, df_new], ignore_index=True)
    df_combined['_d'] = df_combined['Driver'].map(DRIVER_ORDER)
    df_combined = df_combined.sort_values('_d', kind='stable').drop(columns='_d').reset_index(drop=True)
    df_combined.to_csv(OUTPUT_CSV, index=False)
    print(f"\n✓ Updated: {OUTPUT_CSV}")
    print(f"  Final rows:    {len(df_combined):,}")
    print(f"  Final metrics: {df_combined['Metric'].nunique()}")
    print(f"\n  Rows per Driver:")
    print(df_combined['Driver'].value_counts().sort_index().to_string())
else:
    df_new.to_csv(OUTPUT_CSV, index=False)
    print(f"✓ Created: {OUTPUT_CSV} ({len(df_new):,} rows)")

print("\nDone.")
