"""
CORDA Democracy — Full V-Dem Variable Extractor
================================================
Run this script ONCE after downloading the V-Dem dataset.

STEP 1: Download the V-Dem dataset (free, no registration required):
    Option A — GitHub (fastest):
        https://raw.githubusercontent.com/vdeminstitute/vdemdata/master/data/vdem.RData
        Save as:  vdem.RData  (in the same folder as this script)

    Option B — Official CSV (v-dem.net):
        Go to https://v-dem.net/data/the-v-dem-dataset/country-year-v-dem-core-v15/
        Download the ZIP, extract V-Dem-CY-Core-v15.csv
        Rename to:  vdem.csv  (in the same folder as this script)

STEP 2: Install dependencies (if needed):
    pip install pyreadr pandas

STEP 3: Run this script:
    python3 extract_vdem_full.py

OUTPUT: vdem_corda_extracted.csv  — appended into non_ai_democracy.csv automatically.
"""

import os, sys
import pandas as pd

# ── Configuration ─────────────────────────────────────────────────────────────

SCRIPT_DIR   = os.path.dirname(os.path.abspath(__file__))
RDATA_PATH   = os.path.join(SCRIPT_DIR, 'vdem.RData')
CSV_PATH     = os.path.join(SCRIPT_DIR, 'vdem.csv')
OUTPUT_CSV   = os.path.join(SCRIPT_DIR, 'non_ai_democracy.csv')
TEMP_OUTPUT  = os.path.join(SCRIPT_DIR, 'vdem_corda_extracted.csv')

CORDA_ISO3 = {
    'AUS','BGD','BRA','CAN','CHL','CHN','DNK','FRA','DEU','GHA','IND','IDN',
    'ISR','JPN','MEX','NLD','NZL','NGA','POL','SGP','ZAF','KOR','SWE','TWN',
    'ARE','GBR','USA'
}
ISO3_NAME = {
    'AUS':'Australia','BGD':'Bangladesh','BRA':'Brazil','CAN':'Canada',
    'CHL':'Chile','CHN':'China','DNK':'Denmark','FRA':'France','DEU':'Germany',
    'GHA':'Ghana','IND':'India','IDN':'Indonesia','ISR':'Israel','JPN':'Japan',
    'MEX':'Mexico','NLD':'Netherlands','NZL':'New Zealand','NGA':'Nigeria',
    'POL':'Poland','SGP':'Singapore','ZAF':'South Africa','KOR':'South Korea',
    'SWE':'Sweden','TWN':'Taiwan','ARE':'United Arab Emirates',
    'GBR':'United Kingdom','USA':'United States'
}

# ── V-Dem variables to extract ────────────────────────────────────────────────
# Format: (vdem_column, metric_label, driver, dimension_note)

VDEM_VARS = [
    # ── T1/D1 — Economic Inequality / Relative Deprivation ──────────────────
    ('v2x_egal',       'v2x_egal: Egalitarian Component Index (0-1)',
     'T1/D1 (Economic Inequality/Relative Deprivation)', 'Preparedness'),
    ('v2xeg_eqdr',     'v2xeg_eqdr: Equal Distribution of Resources Index (0-1)',
     'T1/D1 (Economic Inequality/Relative Deprivation)', 'Exposure'),
    ('v2xeg_eqaccess', 'v2xeg_eqaccess: Equal Access Index (0-1)',
     'T1/D1 (Economic Inequality/Relative Deprivation)', 'Exposure'),
    ('v2xeg_eqprotec', 'v2xeg_eqprotec: Equal Protection Index (0-1)',
     'T1/D1 (Economic Inequality/Relative Deprivation)', 'Preparedness'),
    ('v2pepwrses',     'v2pepwrses: Power Distributed by Socioeconomic Position (0-4)',
     'T1/D1 (Economic Inequality/Relative Deprivation)', 'Exposure'),

    # ── T1/D2 — Information Environment Shocks ──────────────────────────────
    ('v2x_freexp_altinf', 'v2x_freexp_altinf: Freedom of Expression and Alternative Information Index (0-1)',
     'T1/D2 (Information Environment Shocks)', 'Preparedness'),
    ('v2mecenefm',     'v2mecenefm: Government Censorship Effort — Media (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2mecenefi',     'v2mecenefi: Internet Censorship Effort (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2meharjrn',     'v2meharjrn: Harassment of Journalists (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2meslfcen',     'v2meslfcen: Media Self-Censorship (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2merange',      'v2merange: Range of Media Perspectives (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Preparedness'),
    ('v2mebias',       'v2mebias: Government Media Bias (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    # DSP variables (also in Digital Society Project subset)
    ('v2smgovdom',     'v2smgovdom: Government Dissemination of False Information Domestic (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2smgovab',      'v2smgovab: Government Dissemination of False Information Abroad (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2smfordom',     'v2smfordom: Foreign Government Dissemination of False Information (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2smregcon',     'v2smregcon: Internet Legal Regulation Content (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),
    ('v2smregapp',     'v2smregapp: Government Online Content Regulation Approach (0-4)',
     'T1/D2 (Information Environment Shocks)', 'Exposure'),

    # ── T1/D3 — Elite Defection / Intra-Elite Conflict ──────────────────────
    ('v2psoppaut',     'v2psoppaut: Opposition Parties Autonomy (0-4)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Preparedness'),
    ('v2pscohesv',     'v2pscohesv: Legislative Party Cohesion (0-4)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Preparedness'),
    ('v2psprbrch',     'v2psprbrch: Party Branches (0-3)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Preparedness'),
    ('v2psprlnks',     'v2psprlnks: Party-Population Linkages (0-5)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Preparedness'),
    ('v2psplats',      'v2psplats: Party Platforms (0-3)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Preparedness'),
    ('v2elirreg',      'v2elirreg: Election Irregularities (0-4)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Exposure'),
    ('v2elintim',      'v2elintim: Election Government Intimidation (0-4)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Exposure'),
    ('v2elboycot',     'v2elboycot: Election Boycotts (0-3)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Exposure'),
    ('v2x_elecreg',    'v2x_elecreg: Electoral Regime Index (0-1)',
     'T1/D3 (Elite Defection/Intra-Elite Conflict)', 'Preparedness'),

    # ── T1/D4 — State Capacity Erosion ──────────────────────────────────────
    ('v2x_neopat',     'v2x_neopat: Neopatrimonial Rule Index (0-1)',
     'T1/D4 (State Capacity Erosion)', 'Exposure'),
    ('v2x_corr',       'v2x_corr: Political Corruption Index (0-1)',
     'T1/D4 (State Capacity Erosion)', 'Exposure'),
    ('v2excrptps',     'v2excrptps: Public Sector Corrupt Exchanges (0-4)',
     'T1/D4 (State Capacity Erosion)', 'Exposure'),
    ('v2stcritrecadm', 'v2stcritrecadm: Criteria for State Administration Appointments (0-4)',
     'T1/D4 (State Capacity Erosion)', 'Preparedness'),
    ('v2strenadm',     'v2strenadm: Bureaucratic Remuneration (0-4)',
     'T1/D4 (State Capacity Erosion)', 'Preparedness'),
    ('v2svstterr',     'v2svstterr: Percentage of Territory Under State Control (0-100)',
     'T1/D4 (State Capacity Erosion)', 'Preparedness'),
    ('v2regfunds',     'v2regfunds: Public Party Financing (0-4)',
     'T1/D4 (State Capacity Erosion)', 'Preparedness'),

    # ── T1/D5 — Polarization / Affective Tribalism ──────────────────────────
    ('v2cacamps',      'v2cacamps: Political Polarisation (interval scale)',
     'T1/D5 (Polarization/Affective Tribalism)', 'Exposure'),
    ('v2caautmob',     'v2caautmob: Mobilisation for Autocracy (0-4)',
     'T1/D5 (Polarization/Affective Tribalism)', 'Exposure'),
    ('v2cademmob',     'v2cademmob: Mobilisation for Democracy (0-4)',
     'T1/D5 (Polarization/Affective Tribalism)', 'Preparedness'),
    ('v2caviol',       'v2caviol: Political Violence (0-4)',
     'T1/D5 (Polarization/Affective Tribalism)', 'Exposure'),
    # DSP / Social Media variables
    ('v2smpolsoc',     'v2smpolsoc: Polarisation of Society (0-4)',
     'T1/D5 (Polarization/Affective Tribalism)', 'Exposure'),
    ('v2smmefra',      'v2smmefra: Social Media Freedom and Fractionalization (0-4)',
     'T1/D5 (Polarization/Affective Tribalism)', 'Exposure'),
    ('v2smpolhate',    'v2smpolhate: Political Parties Hate Speech Online (0-4)',
     'T1/D5 (Polarization/Affective Tribalism)', 'Exposure'),
]

# ── Load V-Dem data ───────────────────────────────────────────────────────────

vdem = None

if os.path.exists(RDATA_PATH):
    print(f"Loading V-Dem from RData: {RDATA_PATH}")
    try:
        import pyreadr
        result = pyreadr.read_r(RDATA_PATH)
        key = list(result.keys())[0]
        vdem = result[key]
        print(f"  Loaded: {vdem.shape[0]:,} rows × {vdem.shape[1]} columns")
    except ImportError:
        print("ERROR: pyreadr not installed. Run: pip install pyreadr")
        sys.exit(1)
    except Exception as e:
        print(f"ERROR loading RData: {e}")
        sys.exit(1)

elif os.path.exists(CSV_PATH):
    print(f"Loading V-Dem from CSV: {CSV_PATH}")
    vdem = pd.read_csv(CSV_PATH, low_memory=False)
    print(f"  Loaded: {vdem.shape[0]:,} rows × {vdem.shape[1]} columns")

else:
    print("ERROR: No V-Dem data file found.")
    print("  Expected either:")
    print(f"    {RDATA_PATH}")
    print(f"    {CSV_PATH}")
    print("\nDownload from:")
    print("  https://raw.githubusercontent.com/vdeminstitute/vdemdata/master/data/vdem.RData")
    print("  or https://v-dem.net/data/the-v-dem-dataset/country-year-v-dem-core-v15/")
    sys.exit(1)

# ── Identify key columns ──────────────────────────────────────────────────────

# V-Dem uses 'country_text_id' (ISO3) and 'year'
iso3_col  = next((c for c in ['country_text_id','iso3','ISO3','country_id'] if c in vdem.columns), None)
year_col  = next((c for c in ['year','Year'] if c in vdem.columns), None)

if iso3_col is None or year_col is None:
    print(f"Columns available: {list(vdem.columns[:30])}")
    print("ERROR: Cannot identify ISO3 or Year column.")
    sys.exit(1)

print(f"  ISO3 column: '{iso3_col}', Year column: '{year_col}'")

# Filter for CORDA countries
vdem_corda = vdem[vdem[iso3_col].isin(CORDA_ISO3)].copy()
print(f"  CORDA rows: {len(vdem_corda):,} (years {vdem_corda[year_col].min()}–{vdem_corda[year_col].max()})")

# ── Extract rows ──────────────────────────────────────────────────────────────

rows = []
missing_vars = []

DRIVER_ORDER = {
    'T1/D1 (Economic Inequality/Relative Deprivation)':0,
    'T1/D2 (Information Environment Shocks)':1,
    'T1/D3 (Elite Defection/Intra-Elite Conflict)':2,
    'T1/D4 (State Capacity Erosion)':3,
    'T1/D5 (Polarization/Affective Tribalism)':4,
}

for vdem_col, metric_label, driver, _ in VDEM_VARS:
    if vdem_col not in vdem_corda.columns:
        missing_vars.append(vdem_col)
        continue
    sub = vdem_corda[[iso3_col, year_col, vdem_col]].dropna(subset=[vdem_col])
    for _, r in sub.iterrows():
        iso3 = r[iso3_col]
        if iso3 not in ISO3_NAME:
            continue
        rows.append({
            'Year':        int(r[year_col]),
            'Country':     ISO3_NAME[iso3],
            'ISO3':        iso3,
            'Driver':      driver,
            'Metric':      metric_label,
            'Value':       round(float(r[vdem_col]), 6),
            'Dataset':     'V-Dem',
            'Source':      'V-Dem Institute',
            'Source_File': 'vdem.RData (vdeminstitute/vdemdata on GitHub)',
            'Source_Type': 'RData',
            'Source_Year': 2026,
        })

print(f"\nExtracted {len(rows):,} rows from {len(VDEM_VARS) - len(missing_vars)} variables")
if missing_vars:
    print(f"Variables not found in dataset: {missing_vars}")
    print("(These may use a different column name in the version you downloaded.)")

# ── Save extracted file ───────────────────────────────────────────────────────

df_new = pd.DataFrame(rows)
df_new['_d'] = df_new['Driver'].map(DRIVER_ORDER)
df_new = df_new.sort_values(['_d','Metric','Country','Year'], kind='stable').drop(columns='_d')

df_new.to_csv(TEMP_OUTPUT, index=False)
print(f"\n✓ Saved extracted V-Dem data to: {TEMP_OUTPUT}")

# ── Merge into non_ai_democracy.csv ──────────────────────────────────────────

if os.path.exists(OUTPUT_CSV):
    df_existing = pd.read_csv(OUTPUT_CSV)

    # Remove any V-Dem rows already in the file (from OWID partial extracts)
    vdem_metrics_in_new = set(df_new['Metric'].unique())
    df_existing_filtered = df_existing[~df_existing['Metric'].isin(vdem_metrics_in_new)]
    n_replaced = len(df_existing) - len(df_existing_filtered)
    if n_replaced > 0:
        print(f"Replaced {n_replaced} partial V-Dem rows from OWID with full V-Dem data")

    df_combined = pd.concat([df_existing_filtered, df_new], ignore_index=True)
    df_combined['_d'] = df_combined['Driver'].map(DRIVER_ORDER)
    df_combined = df_combined.sort_values('_d', kind='stable').drop(columns='_d').reset_index(drop=True)
    df_combined.to_csv(OUTPUT_CSV, index=False)

    print(f"✓ Updated: {OUTPUT_CSV}")
    print(f"  Final rows: {len(df_combined):,}")
    print(f"  Final metrics: {df_combined['Metric'].nunique()}")
    print(f"\n  Rows per Driver:")
    print(df_combined['Driver'].value_counts().sort_index().to_string())
else:
    print(f"\nNote: {OUTPUT_CSV} not found. Saved to {TEMP_OUTPUT} only.")
    print("Move or rename the file, or update OUTPUT_CSV path at the top of this script.")

print("\nDone.")
